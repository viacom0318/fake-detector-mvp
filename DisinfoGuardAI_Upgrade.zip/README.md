# DisinfoGuard AI Upgrade

## 專案簡介
- 升級版 Dashboard Demo，圖示化假帳號分析
- 可部署到 Netlify / Vercel / Cloudflare Pages
- 功能: 假帳號風險分數、Bot Network Graph、消息擴散 Timeline、多語系切換

## 部署步驟
1. 將整個 `DisinfoGuardAI_Upgrade/` 資料夾上傳到 GitHub
2. 登入 [Netlify](https://app.netlify.com/) → New site from Git → 選取 GitHub 專案
3. Netlify 自動部署完成後生成公開 URL
4. 點擊 URL 即可測試 Dashboard
